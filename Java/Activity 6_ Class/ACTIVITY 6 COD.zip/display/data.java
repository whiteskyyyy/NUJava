package display;

class data {

    public static void main(String[]args){
        //clearscreen//
        clearScreen();

        displayed tt = new displayed();

        //clearscreen//
        clearScreen();

        //display all of information//
        //use print f for a cleaner format//
        System.out.println("=============================================");
        System.out.printf("%-10s","\nName: ");
        System.out.printf("%-10s", tt.Lastname + ", " + tt.Firstname);
        System.out.printf("%-10s","\nAge: ");
        System.out.printf("%-10s", tt.age);
        System.out.printf("%-10s","\nAddress: ");
        System.out.printf("%-10s", tt.Address);
        System.out.println("\n\n=============================================");
    }

    //code for clearscreen//
    public static void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }  
}
