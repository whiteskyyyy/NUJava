package display;
import java.util.*;

class displayed {
    String Lastname, Firstname, Address;
    int age;

    static Scanner cl = new Scanner (System.in);
    public displayed(){
        //ask for details//
        System.out.println("Enter the following details: ");
        //input last//
        System.out.print("Enter Last Name: ");
        Lastname = cl.next();
        //input given//
        System.out.print("Enter Given Name: ");
        Firstname = cl.next();
        //input age//
        System.out.print("Enter Age: ");
        age = cl.nextInt();
        cl.nextLine();
        //input address//
        System.out.print("Enter Address: ");
        Address = cl.nextLine();

}
}
