package Students;
import java.util.*;

public class name {

    static Scanner cl = new Scanner (System.in);
    public static void main(String[]args){ 
        //clearscreen//
        clearScreen();

        //first object//
        Student first = new Student();

        //Second object//
        Student second = new Student();


        //third object//
        Student third = new Student();
        
        //clearscreen//
        clearScreen();
        //print out all of the data gathered//
        //using printf for formatting spacing//
        System.out.println("=============================================");
        System.out.println("Student Names: ");
        System.out.printf("%-15s", "Last Name:");
        System.out.printf("%-15s", "Given Name:");
        System.out.printf("%-15s", "ID Number:");
        System.out.println();
        System.out.println();

        System.out.printf("%-15s",first.Lastname);
        System.out.printf("%-15s", first.Firstname);
        System.out.printf("%-15s", first.IDno);
        System.out.println();
        System.out.println();

        System.out.printf("%-15s", second.Lastname);
        System.out.printf("%-15s", second.Firstname);
        System.out.printf("%-15s", second.IDno);
        System.out.println();
        System.out.println();


        System.out.printf("%-15s", third.Lastname);
        System.out.printf("%-15s", third.Firstname);
        System.out.printf("%-15s", third.IDno);
        System.out.println();
        System.out.println("=============================================");
    
    }
    
    //code for clearscreen//
    public static void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }  
}
