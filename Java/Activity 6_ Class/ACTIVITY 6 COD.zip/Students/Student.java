package Students;
import java.util.*;

//class student//
class Student {
    static Scanner cl = new Scanner (System.in);
    //attributes//
    String Lastname;
    String Firstname;
    String IDno;
    
    //constructor//
    public Student(){
        //ask for details//
        System.out.println("Enter the following details: ");
        System.out.print("Last Name: ");
        //input lastname//
        Lastname = cl.nextLine();
        System.out.print("Given Name: ");
        //input first name//
        Firstname = cl.nextLine();
        System.out.print("ID number: ");
        //input id number//
        IDno = cl.nextLine();
        System.out.println();
        System.out.println();
    }
}
