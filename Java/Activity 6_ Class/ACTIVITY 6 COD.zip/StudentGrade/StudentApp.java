package StudentGrade;
import java.util.*;

//class student//
class StudentApp {
    static Scanner cl = new Scanner (System.in);
    //attributes//
    String Name;
    float MGRADE, SGRADE, EGRADE;
    
    //constructor//
    public StudentApp(){
        //ask for details//
        System.out.println("Enter the following details: ");
        System.out.print("Enter Name: ");
        //input Name//
        Name = cl.nextLine();
        System.out.print("Enter Math Grade: ");
        //input math grade//
        MGRADE = cl.nextFloat();
        System.out.print("Enter Science Grade: ");
        //input Science grade//
        SGRADE = cl.nextFloat();
        System.out.print("Enter Science Grade: ");
        //input English grade//
        EGRADE = cl.nextFloat();
        System.out.println();
        System.out.println();


    }
}