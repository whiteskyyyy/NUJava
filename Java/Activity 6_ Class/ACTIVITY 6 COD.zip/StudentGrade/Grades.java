package StudentGrade;
import java.util.*;

class Grades {
    static Scanner cl = new Scanner (System.in);
    public static void main(String[]args){ 
        //clearscreen//
        clearScreen();

        float avg;
        String pf;
        //apply object//
        StudentApp gr = new StudentApp();

        //clearscreen//
        clearScreen();

        //display all of information//
        //use print f for a cleaner format//
        System.out.println("=============================================");
        System.out.println(gr.Name);
        System.out.printf("%-15s","Math Grade: ");
        System.out.printf("%-15s", gr.MGRADE );
        System.out.printf("%-15s","\nScience Grade: ");
        System.out.printf("%-15s", gr.SGRADE );
        System.out.printf("%-15s","\nEnglish Grade: ");
        System.out.printf("%-15s", gr.EGRADE );

        //average calculator//
        avg = (gr.MGRADE + gr.SGRADE + gr.EGRADE)/3;

        //pass or fail indentifier//
        if(avg>=60){
            pf = "PASSED";
        }
        else{
            pf = "FAILED";
        }

        //display all of information//
        //use print f for a cleaner format//
        System.out.printf("%-15s","\nAverage Grade: ");
        System.out.printf("%-15s", avg );
        System.out.printf("%-15s", "\n=" );
        System.out.printf("%-15s", pf );
        System.out.println("\n=============================================");

    }


    //code for clearscreen//
    public static void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }  
}
